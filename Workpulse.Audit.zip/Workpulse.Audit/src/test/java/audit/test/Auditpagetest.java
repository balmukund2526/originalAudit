package audit.test;

import org.testng.annotations.Test;

import audit.pages.Auditpage;
import wp.base.Baseclass;

public class Auditpagetest extends Baseclass {

	Auditpage adp = new Auditpage();;
	String path = System.getProperty("user.dir") + "\\testdataex\\testdata.xlsx";

	@Test
	public void createform() {
		try {
			adp.auditpageopen();
			System.out.println("ok");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	//	ReadExcelData.setUpExcel(path, "users");
		//String l = ReadExcelData.readExcelCell(1, 1);

	}
}
