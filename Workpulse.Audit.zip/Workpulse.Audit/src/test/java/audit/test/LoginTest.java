package audit.test;


public class LoginTest {

//	LoginPage lpp = new LoginPage();
//
//	//String current = System.getProperty("user.dir");
//	// String path= current+"\\target\\testdata.xlsx";
//	
//	@Test(priority=1,description="login test")
//	public void logintestp() {
//
//		lpp.login();
//
//	}

}
