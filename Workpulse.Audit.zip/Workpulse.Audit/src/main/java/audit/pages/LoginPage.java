package audit.pages;

import org.openqa.selenium.By;

import wp.webelements.CommonHelper;
import wp.webelements.ReadExcelData;

public class LoginPage {

	static By username = By.xpath("//input[@id=\"username\"]");

	static By password = By.xpath("//input[@id=\"password\"]");

	static By accessid = By.xpath("//input[@id=\"accessid\"]");
	static By loginbtn = By.xpath("//button[@id='loginbtn']");

	String current = System.getProperty("user.dir");
	String path = current + "\\testdataex\\testdata.xlsx";

	public void login() {

		ReadExcelData.setUpExcel(path, "users");

		String usernametext = ReadExcelData.readExcelCell(1, 0);
		// System.out.println(usernametext);
		String passwordtext = ReadExcelData.readExcelCell(1, 1);
		String accessidnum = ReadExcelData.readExcelCell(1, 2);

		CommonHelper.enterValues(username, usernametext);
		CommonHelper.enterValues(password, passwordtext);
		CommonHelper.enterValues(accessid, accessidnum);
		CommonHelper.clickOnElement(loginbtn);
	//System.out.println(driver.getTitle());
		// Assert.assertEquals("Dashboard - Workpulse", driver.getTitle());
		System.out.println("login");
		

	}

}
