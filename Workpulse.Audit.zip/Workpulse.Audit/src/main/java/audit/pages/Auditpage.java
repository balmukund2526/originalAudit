package audit.pages;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import adminpages_1.Admin_Pages;
import wp.base.Baseclass;
import wp.webelements.CommonHelper;

public class Auditpage {

	Admin_Pages ad = new Admin_Pages();
	LoginPage lp = new LoginPage();
	

	By audittab = By.xpath("(//span[contains(text(),'Audit')])[1]");
	By forms = By.xpath("(//span[contains(text(),'Forms')])[1]");

	public void auditpageopen() throws InterruptedException {
		
		lp.login();
		System.out.println("logging in");
		Thread.sleep(2000);
		ad.appgrid();
		CommonHelper.clickOnElement(audittab);
		CommonHelper.clickOnElement(forms);
		
		System.out.println("new code is pushed");

	}
}
