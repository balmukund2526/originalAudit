package wp.base;

	import java.util.concurrent.TimeUnit;

	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;
import wp.webelements.CommonHelper;

	public class Baseclass {
		
		public static WebDriver driver;
//		public static Properties prop;
//		public  static EventFiringWebDriver e_driver;
//		public static WebEventListener eventListener;
	//	
//		public TestBase(){
//			try {
//				prop = new Properties();
//				FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+ "/src/main/java/com/crm"
//						+ "/qa/config/config.properties");
//				prop.load(ip);
//			} catch (FileNotFoundException e) {
//				e.printStackTrace();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
		
		@BeforeTest
		public static void initialization(){
			//String browserName = prop.getProperty("browser");
//			
		//	if(browserName.equals("chrome")){
//				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\SKBackend\\clients\\chromedriver.exe");	
//				
//				driver = new ChromeDriver(); 
//			}
//			else if(browserName.equals("FF")){
//				System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"/SKBackend/clients/chromedriver.exe");	
//				driver = new FirefoxDriver(); 
//			}
//			
//			
//			e_driver = new EventFiringWebDriver(driver);
//			// Now create object of EventListerHandler to register it with EventFiringWebDriver
//			eventListener = new WebEventListener();
//			e_driver.register(eventListener);
//			driver = e_driver;
//			
//			driver.manage().window().maximize();
//			driver.manage().deleteAllCookies();
//			driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
//			driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
//			
//			driver.get(prop.getProperty("url"));
//			
//			
//			
			
			
	//	String browserName1 ="chrome";
			//getSystemParameter();
	//BrowserSelection browser = new BrowserSelection(browserName1); 

	WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver(); 
	String BaseUrl= "https://opssite.workpulse.com/";
	driver.get(BaseUrl);
	driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
	System.out.println("123");
	driver.manage().window().maximize();
	
	
		}
		
		
	//	@AfterTest
		public static void methodclose(){
		CommonHelper.driver.close();
		}
		}
	//	
		
		
		
		
		
		
		




