package wp.webelements;

	


	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.IOException;

	import org.apache.poi.ss.usermodel.Row;
	import org.apache.poi.ss.usermodel.Workbook;
	import org.apache.poi.hssf.usermodel.HSSFCell;
	import org.apache.poi.hssf.usermodel.HSSFRow;
	import org.apache.poi.hssf.usermodel.HSSFSheet;
	import org.apache.poi.hssf.usermodel.HSSFWorkbook;
	import org.apache.poi.ss.usermodel.Cell;
	import org.apache.poi.ss.usermodel.DataFormatter;
	import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;
	import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;

	public class ReadExcelData {


		private static XSSFSheet WorkSheet;
		private static XSSFWorkbook WorkBook;
		private XSSFRow SheetRow;
		private XSSFCell RowCell;
		
//		private static HSSFWorkbook WorkBook;
//		private static HSSFSheet WorkSheet;
//		private static HSSFRow SheetRow;
//		private static HSSFCell RowCell;
		private static DataFormatter format= new DataFormatter();
		
		public static XSSFSheet setUpExcel(String ExcelFilePath, String sheetName) {

			try {
				FileInputStream pestream = new FileInputStream(new File(ExcelFilePath));
				WorkBook = new XSSFWorkbook(pestream);
				//Workbook = new xss
				WorkSheet = WorkBook.getSheet(sheetName);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return WorkSheet;

		}
		
//		public String readCellData(int j){
//			try {
//			for(int i=0; i<=WorkSheet.getLastRowNum();i++){
//				
//			String CellData= null;
//			
//			Cell cell= WorkSheet.getRow(i).getCell(j);
//			if(cell!=null){
//				switch (cell.getCellType()) {
//				case Cell.CELL_TYPE_STRING:
//					CellData= cell.getRichStringCellValue().getString();
//					break;
//				case Cell.CELL_TYPE_NUMERIC:
//					int intCellData= (int) cell.getNumericCellValue();
//					CellData= String.valueOf(intCellData);
//				case Cell.CELL_TYPE_BLANK:
//					System.out.println("");
//				//default:
//					break;
//				}
//			}
//			return CellData;
//			} 
//			}
//			
//		}


	public static String readExcelCell(int i, int j){
		try {
		String CellData= null;
		
		Cell cell= WorkSheet.getRow(i).getCell(j);
		if(cell!=null){
			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_STRING:
				CellData= cell.getRichStringCellValue().getString();
				break;
			case Cell.CELL_TYPE_NUMERIC:
				CellData= format.formatCellValue(cell).toString();
//				int intCellData= (int) cell.getNumericCellValue();
//				CellData= String.valueOf(intCellData);
				break;
			case Cell.CELL_TYPE_BLANK:
				CellData=cell.toString();
			}
		}
			else { 
				CellData=cell.toString();
			}			
		return CellData;
				
		} catch (Exception e) {
		// TODO: handle exception
		return "";
			}

		}

	}



