package adminpages_1;

import org.openqa.selenium.By;

import wp.webelements.CommonHelper;

public class Admin_Pages {

	By grid = By.xpath("(//a[@title='My Apps'])[1]");
	By admintile = By.xpath("(//div[contains(text(),'Admin')])[1]");

	public void appgrid() {
System.out.println("ok");
		CommonHelper.clickOnElement(grid);
		CommonHelper.clickOnElement(admintile);
		// CommonHelper.clickOnElement(admintile);

	}
}
